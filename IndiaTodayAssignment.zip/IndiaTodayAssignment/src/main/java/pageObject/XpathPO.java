package pageObject;

public class XpathPO {
    public static String loginForm="//h4[normalize-space()='Login Form']";
    public static String username="//input[@id='username']";
    public static String password="//input[@id='password']";
    public static String logIn="//button[text()='Log In']";
    public static String errorMsg1="//*[text()='Password must be present']";
    public static String errorMsg2="//*[text()='Username must be present']";
    public static String errorMsg3="//*[text()='Both Username and Password must be present ']";
    public static String compareExpense="//a[normalize-space()='Compare Expenses']";
    public static String loginUser="//div[normalize-space()='John Doe']";
    public static String finacialOverview="//h6[normalize-space()='Financial Overview']";
    public static String recentTransaction="//h6[normalize-space()='Recent Transactions']";
}
