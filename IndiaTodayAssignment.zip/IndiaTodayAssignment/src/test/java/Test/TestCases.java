package Test;

import org.openqa.selenium.WebDriver;
import static org.testng.Assert.*;
import org.testng.annotations.*;
import pageObject.XpathPO;

import java.text.MessageFormat;

public class TestCases extends  Setup {
    WebDriver driver ;

    @BeforeClass
    public void tearUp(){
        driver = Setup.launchBrowser("chrome");
        driver.get("https://sakshingp.github.io/assignment/login.html");
    }

    @Test(priority = 1)
    public void checkLoginFormbyEnteringOnlyUsername(){
        assertTrue(Setup.isElementPresent(XpathPO.loginForm));
        Setup.passValueInTextField("Rishabh",XpathPO.username);
        Setup.clickElementByXpath(XpathPO.logIn);
        Setup.waitUntilElementVisible(XpathPO.errorMsg1);
        assertTrue(Setup.isElementPresent(XpathPO.errorMsg1));
    }

    @Test(priority = 2)
    public void checkLoginFormbyEnteringOnlyPassword(){
        driver.navigate().refresh();
        assertTrue(Setup.isElementPresent(XpathPO.loginForm));
        Setup.passValueInTextField("Rishabh@123",XpathPO.password);
        Setup.clickElementByXpath(XpathPO.logIn);
        Setup.waitUntilElementVisible(XpathPO.errorMsg2);
        assertTrue(Setup.isElementPresent(XpathPO.errorMsg2));
    }

    @Test(priority = 3)
    public void verifyIfBothUsernameAndpasswordEmpty(){
        driver.navigate().refresh();
        assertTrue(Setup.isElementPresent(XpathPO.loginForm));
        Setup.clickElementByXpath(XpathPO.logIn);
        Setup.waitUntilElementVisible(XpathPO.errorMsg3);
        assertTrue(Setup.isElementPresent(XpathPO.errorMsg3));
    }

    @Test(priority = 4)
    public void verifyLoginFunctionalityByEnteringUsernameAndPassword(){
        driver.navigate().refresh();
        assertTrue(Setup.isElementPresent(XpathPO.loginForm));
        Setup.passValueInTextField("Rishabh",XpathPO.username);
        Setup.passValueInTextField("Rishabh@123",XpathPO.password);
        Setup.clickElementByXpath(XpathPO.logIn);
        Setup.waitUntilElementVisible(XpathPO.compareExpense);
        assertTrue(Setup.isElementPresent(XpathPO.compareExpense));
        assertTrue(Setup.isElementPresent(XpathPO.loginUser));
        assertTrue(Setup.isElementPresent(XpathPO.finacialOverview));
        assertTrue(Setup.isElementPresent(XpathPO.recentTransaction));
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }

}
