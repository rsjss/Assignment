package Test;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;

import static org.testng.Assert.fail;

public class Setup {
    private static WebDriver driver;


    public static WebDriver launchBrowser(String browserName){
        if(browserName.equalsIgnoreCase("chrome")){
            System.setProperty("webdriver.chrome.driver","chromedriver.exe");
            driver=new ChromeDriver();
        }
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        return driver;
    }

    public static void clickElementByXpath(String xpath){
        try{
            driver.findElement(By.xpath(xpath)).click();
        }catch(NoSuchElementException e){
            System.out.println(e.getMessage()+" Exception is occured");
        }catch(StaleElementReferenceException e2){
            try{
                driver.findElement(By.xpath(xpath)).click();
            }catch(NoSuchElementException e3){
                System.out.println(e3.getMessage()+" Exception is occured");
            }
        }
    }

    public static boolean isElementPresent(String xpath){
        try{
            return driver.findElement(By.xpath(xpath)).isDisplayed();
        }catch(NoSuchElementException e){
            System.out.println("No element is present");
            return false;
        }
    }

    public static void waitUntilElementVisible(String xpath){
        WebDriverWait wait = new WebDriverWait(driver, 10);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
        } catch (TimeoutException e) {
            fail("Element is not located till the time provided " + e.getMessage());
        }
    }

    public static void passValueInTextField(String input,String xpath){
        try{
             WebElement el = driver.findElement(By.xpath(xpath));
             el.sendKeys(input);
        }catch(NoSuchElementException e){
            System.out.println(e.getMessage()+" Exception is occured");
        }
    }


}
